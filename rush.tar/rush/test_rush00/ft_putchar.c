/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pnimwata <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 13:42:05 by pnimwata          #+#    #+#             */
/*   Updated: 2022/01/16 14:40:09 by pnimwata         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
 *	This is ft_putchar function.
 *	This function will print the character of c to output.
 */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
