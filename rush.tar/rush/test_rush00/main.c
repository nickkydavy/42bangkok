/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pnimwata <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 13:42:19 by pnimwata          #+#    #+#             */
/*   Updated: 2022/01/16 14:42:18 by pnimwata         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
 *	This is a main function.
 *	This function use a rush function to print a rectangle of x, y 
 *	x = width
 *	y = length
 */

void	ft_putchar(char c);
void	rush(int x, int y);

int	main(void)
{
	rush(123, 42);
	return (0);
}
