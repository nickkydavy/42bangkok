/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pnimwata <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 14:38:20 by pnimwata          #+#    #+#             */
/*   Updated: 2022/01/16 14:38:31 by pnimwata         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
 *	this is a rush00 to print like this of you use rush(5, 3);
 *	o---o
 *	|   |
 *	o---o
 */

void	ft_putchar(char c);

void	print_first_or_last_line(int x)
{
	int	i;

	i = 0;
	while (i < x)
	{
		if ((i == 0) || (i == x - 1))
			ft_putchar('o');
		else
			ft_putchar('-');
		i++;
	}
}

void	print_line(int x)
{
	int	i;

	i = 0;
	while (i < x)
	{
		if ((i == 0) || (i == x - 1))
			ft_putchar('|');
		else
			ft_putchar(' ');
		i++;
	}
}

void	rush(int x, int y)
{
	int	i;

	i = 0;
	while (i < y)
	{
		if ((i == 0) || i == y - 1)
			print_first_or_last_line(x);
		else
			print_line(x);
		ft_putchar('\n');
		i++;
	}
}
