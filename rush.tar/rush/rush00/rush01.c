/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ncharuva <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/14 23:17:08 by ncharuva          #+#    #+#             */
<<<<<<< HEAD
/*   Updated: 2022/01/15 01:23:10 by pnimwata         ###   ########.fr       */
=======
/*   Updated: 2022/01/15 01:35:05 by ncharuva         ###   ########.fr       */
>>>>>>> 6eaead41c14e03ebfb15cd393da529e56f67e436
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

<<<<<<< HEAD
void	ft_putchar(int a);
=======
void	ft_putchar(int i, int j, int x, int y);
>>>>>>> 6eaead41c14e03ebfb15cd393da529e56f67e436

void	rush01(int x, int y)

{
	int	i;
	int	j;

	i = 0;
	while (i < y)
	{
		j = 0;
		while (j < x)
		{
<<<<<<< HEAD
			if ((i == 0 && j == 0) || (i == x - 1 && j == y - 1))
				ft_putchar(47);
			else if ((i == 0 && j == y - 1) || (i == x - 1 && j == 0))
				ft_putchar(92);
			else if ((i == 0 || i == x - 1) || (j == 0 || j == y - 1))
				ft_putchar(42);
			else
				ft_putchar(32);
			++j;
		}
		ft_putchar('\n');
=======
			ft_putchar(i, j, x, y);
			++j;
		}
		write(1, "\n", 1);
>>>>>>> 6eaead41c14e03ebfb15cd393da529e56f67e436
		++i;
	}
}
