git ls-files --ignored --others --exclude-standard
